import random

Hater1 = 3
PlayerHP = 3

print("You have 3 lives, if you lose three rounds, you'll be returned to the start of the maze, stay safe!")

if character_selection == "3":
    print("""

You've found a hater!
_________________________
|                       |   
|   o [|]       @!@     |
|   |--|        %$#     | 
|   |\ |        / \     |
\_______________________/

What will you do? Bash, Dodge, or Strike?
                   1      2         3""")

    while int(Hater1) > 0:
        moveChoice = input()
        if moveChoice == "Dab":
            print("You dabbed on the hater and it was instantly defeated!")
            print("""
                _________________________
                |               _____   |   
                |  <o/         { @!@ }  |
                |   |          / %$# \  | 
                |   |\         \ / \ /  |
                \_______________________/""")
            print("""
                            _________________________
                            |                       |   
                            |  <o/            ==    |
                            |   |             ||    | 
                            |   |\            <>    |
                            \_______________________/""")
            Hater1 = Hater1 - 1000
        else:
            moveChoice = int(moveChoice)
            haterChoice = int(random.randint(1, 3))
            if moveChoice == haterChoice:
                print("It was a tie")
            # Bash->Dodge
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 3:
                print("You bashed the hater, two more hits like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 2:
                print("You bashed the hater, one more hit like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 1:
                print("You bashed the hater!")
                Hater1 = Hater1 - 1
            # Bash->Strike
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 3:
                print("You were struck by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 2:
                print("You were struck by the hater, one more hit like that and you'll be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 1:
                print("You were struck by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());
            # Dodge->Strike
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 3:
                print("You dodged the hater, two more successes like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 2:
                print("You dodged the hater, one more success like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 1:
                print("You dodged the hater!")
                Hater1 = Hater1 - 1
            # Dodge->Bash
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 3:
                print("You were bashed by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 2:
                print("You were bashed by the hater, one more hit like that and you will be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 1:
                print("You were bashed by the hater!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());
            # Strike->Bash
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 3:
                print("You struck the hater, two more hits like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 2:
                print("You struck the hater, one more success like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 1:
                print("You struck the hater!")
                Hater1 = Hater1 - 1
            # Strike->Dodge
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 3:
                print("You were dodged by the hater, two more failures like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 2:
                print(
                    "You were dodged by the hater, one more fail like that and you will be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 1:
                print("You were dodged by the hater!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());

    print("You have stopped the hater! Now, get back to the maze!")
    exec(open("input_movementHater3.py").read());

elif character_selection == "1":
    print("""

You've found a hater!
_________________________
|                       |   
|   o   __      @!@     |
|   |--/  *     %$#     | 
|   |\          / \     |
\_______________________/

What will you do? Bash, Dodge, or Strike?
                   1      2         3""")

    while int(Hater1) > 0:
        moveChoice = input()
        if moveChoice == "Dab":
            print("You dabbed on the hater and it was instantly defeated!")
            print("""
                _________________________
                |               _____   |   
                |  <o/         { @!@ }  |
                |   |          / %$# \  | 
                |   |\         \ / \ /  |
                \_______________________/""")
            print("""
                            _________________________
                            |                       |   
                            |  <o/                  |
                            |   |          <(*)     | 
                            |   |\          (__)    |
                            \_______________________/""")
            Hater1 = Hater1 - 1000
        else:
            moveChoice = int(moveChoice)
            haterChoice = int(random.randint(1, 3))
            if moveChoice == haterChoice:
                print("It was a tie")
            # Bash->Dodge
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 3:
                print("You bashed the hater, two more hits like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 2:
                print("You bashed the hater, one more hit like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 1:
                print("You bashed the hater!")
                Hater1 = Hater1 - 1
            # Bash->Strike
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 3:
                print("You were struck by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 2:
                print("You were struck by the hater, one more hit like that and you'll be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 1:
                print("You were struck by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());
            # Dodge->Strike
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 3:
                print("You dodged the hater, two more successes like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 2:
                print("You dodged the hater, one more success like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 1:
                print("You dodged the hater!")
                Hater1 = Hater1 - 1
            # Dodge->Bash
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 3:
                print("You were bashed by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 2:
                print("You were bashed by the hater, one more hit like that and you will be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 1:
                print("You were bashed by the hater!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());
            # Strike->Bash
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 3:
                print("You struck the hater, two more hits like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 2:
                print("You struck the hater, one more success like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 1:
                print("You struck the hater!")
                Hater1 = Hater1 - 1
            # Strike->Dodge
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 3:
                print("You were dodged by the hater, two more failures like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 2:
                print(
                    "You were dodged by the hater, one more fail like that and you will be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 1:
                print("You were dodged by the hater!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());

    print("You have stopped the hater! Now, get back to the maze!")
    exec(open("input_movementHater3.py").read());


elif character_selection == "2":
    print("""

You've found a hater!
_________________________
|                       |   
|  ;o;|         @!@     |
|   |-t         %$#     | 
|   |\          / \     |
\_______________________/

What will you do? Bash, Dodge, or Strike?
                   1      2         3""")

    while int(Hater1) > 0:
        moveChoice = input()
        if moveChoice == "Dab":
            print("You dabbed on the hater and it was instantly defeated!")
            print("""
                _________________________
                |               _____   |   
                |  <o/         { @!@ }  |
                |   |          / %$# \  | 
                |   |\         \ / \ /  |
                \_______________________/""")
            print("""
                            _________________________
                            |                       |   
                            |  <o/                  |
                            |   |                   | 
                            |   |\            <>    |
                            \_______________________/""")
            Hater1 = Hater1 - 1000
        else:
            moveChoice = int(moveChoice)
            haterChoice = int(random.randint(1, 3))
            if moveChoice == haterChoice:
                print("It was a tie")
            # Bash->Dodge
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 3:
                print("You bashed the hater, two more hits like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 2:
                print("You bashed the hater, one more hit like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 1 and haterChoice == 2 and Hater1 == 1:
                print("You bashed the hater!")
                Hater1 = Hater1 - 1
            # Bash->Strike
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 3:
                print("You were struck by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 2:
                print("You were struck by the hater, one more hit like that and you'll be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 1 and haterChoice == 3 and PlayerHP == 1:
                print("You were struck by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());
            # Dodge->Strike
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 3:
                print("You dodged the hater, two more successes like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 2:
                print("You dodged the hater, one more success like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 2 and haterChoice == 3 and Hater1 == 1:
                print("You dodged the hater!")
                Hater1 = Hater1 - 1
            # Dodge->Bash
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 3:
                print("You were bashed by the hater, two more hits like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 2:
                print("You were bashed by the hater, one more hit like that and you will be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 2 and haterChoice == 1 and PlayerHP == 1:
                print("You were bashed by the hater!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());
            # Strike->Bash
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 3:
                print("You struck the hater, two more hits like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 2:
                print("You struck the hater, one more success like that and it will fall!")
                Hater1 = Hater1 - 1
            elif moveChoice == 3 and haterChoice == 1 and Hater1 == 1:
                print("You struck the hater!")
                Hater1 = Hater1 - 1
            # Strike->Dodge
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 3:
                print("You were dodged by the hater, two more failures like that and you will fall!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 2:
                print(
                    "You were dodged by the hater, one more fail like that and you will be sent back to the start!")
                PlayerHP = PlayerHP - 1
            elif moveChoice == 3 and haterChoice == 2 and PlayerHP == 1:
                print("You were dodged by the hater!")
                PlayerHP = PlayerHP - 1
                if PlayerHP == 0:
                    print("You were slain by the hater, too bad!")
                    exec(open("Death_Screen.py").read());

    print("You have stopped your second hater! Now, get back to the maze!")
    exec(open("input_movementHater3.py").read());
