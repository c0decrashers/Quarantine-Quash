player_x = 17
player_y = 7
in_combat = False
phase = False
maze = """
 _______________________________/ _ \_______________________________  
|           |       |               |           |       |           |
|    ___    |       |_______     ___|    ___    |___    |_______    |
|   |       |   |                           |       |   |           |
|   |___    |   |        _______________    |___    |   |   ________|
|   |       |   |   |           |       |       |   |   |           |
|   |    ___|   |   |    ___    |       |___    |_______|    ___    |
|   |       |   |   |       |       |       |           |   |       |
|___|___    |   |   |___    |_______|_______|_______    |   |   ____|
|       |   |   |   |       |                   |   |       |       |
|       |   |   |___|    ___|___         ___    |   |_______|___    |
|   |   |   |       |           |   |   |       |               |   |
|   |   |   |___    |_______    |___|   |       |    ___     ___|   |
|   |   |       |       |       |       |   |   |       |   |     o |
|   |   |___    |___    |    ___|    ___|   |   |_______|   |       |
|   |       |   |       |           |       |               |   |   |
|   |___    |   |    ___|___________|    ___|_______________|   |   |
|       |       |   |           |                           |   |   |
|___    |    ___|   |           |_______     _______________|   |___|
|       |               |   |           |                   |       |
|    ___|_______________|   |___________|_______________    |___    |
|   |               |       |                           |       |   |
|___|    _______    |_______|    ___________________    |___    |   |
|               |     x         |               |   |   |       |   |
|    ________   |___     _______|    _______    |   |   |    ___|   |
|   |           |       |       |           |   |   |   |   |       |
|   |___________|_______|       |___________|   |   |   |___|       |
|                       |   |               |       |   |       |   |
|_______     ___        |___|_______        |___    |   |    ___|   |
|   |       |       |   |           |   |           |       |       |
|   |    ___|    ___|   |    ___    |   |___________|_______|    ___|
|   |   |   |   |   |       |       |   |       |       |       |   |
|   |   |   |   |   |    ___|    ___|   |       |    ___|    ___|   |
|       |           | x     |       |       |                       |
|_______|___________|_______|____/ \|_______|_______________________|
"""

#haters
hater_17_7 = False
hater_6_12 = True
hater_6_17 = True

while not in_combat:

#maze
    print(maze)
    player_location = maze.find("o")

#encounters
    if player_y == 18:
        player_y = 0
        exec(open("level_2_intro.py").read())

    if player_x == 17 and player_y == 7 and hater_17_7 == True:
        hater_17_7 = False
        exec(open("CombatStart.py").read())

    if player_x == 6 and player_y == 12 and hater_6_12 == True:
        hater_6_12 = False
        exec(open("SecondHater.py").read())

    if player_x == 6 and player_y == 17 and hater_6_17 == True:
        hater_6_17 = False
        exec(open("ThirdHater.py").read())

#input movement
    press = input("")
    if str(press) == str("w") and maze[player_location - 71] != "_":

        print("move up")
        player_y -= 1
        print("Player X: " + str(player_x))
        print("Player Y: " + str(player_y))

        player_location -= 140
        maze = maze.replace("o", " ")
        new_maze = maze[:player_location] + "o" + maze[(player_location + 1):]
        maze = new_maze

    elif str(press) == str("s") and maze[player_location + 71] != "_":

        print("move down")
        player_y += 1
        print("Player X: " + str(player_x))
        print("Player Y: " + str(player_y))

        player_location += 140
        maze = maze.replace("o", " ")
        new_maze = maze[:player_location] + "o" + maze[(player_location + 1):]
        maze = new_maze

    elif str(press) == str("a") and maze[player_location - 2] != "|":

        print("move left")
        player_x -= 1
        print("Player X: " + str(player_x))
        print("Player Y: " + str(player_y))

        player_location -= 4
        maze = maze.replace("o", " ")
        new_maze = maze[:player_location] + "o" + maze[(player_location + 1):]
        maze = new_maze

    elif str(press) == str("d") and maze[player_location + 2] != "|":

        print("move right")
        player_x += 1
        print("Player X: " + str(player_x))
        print("Player Y: " + str(player_y))

        player_location += 4
        maze = maze.replace("o", " ")
        new_maze = maze[:player_location] + "o" + maze[(player_location + 1):]
        maze = new_maze

    elif str(press) == str("togglephase"):

        print("phase activated!")
        phase = True

    elif str(press) == str("i") and phase == True:

        print("move up")
        player_y -= 1
        print("Player X: " + str(player_x))
        print("Player Y: " + str(player_y))

        player_location -= 140
        maze = maze.replace("o", " ")
        new_maze = maze[:player_location] + "o" + maze[(player_location + 1):]
        maze = new_maze

    elif str(press) == str("k") and phase == True:

        print("move down")
        player_y += 1
        print("Player X: " + str(player_x))
        print("Player Y: " + str(player_y))

        player_location += 140
        maze = maze.replace("o", " ")
        new_maze = maze[:player_location] + "o" + maze[(player_location + 1):]
        maze = new_maze

    elif str(press) == str("j") and phase == True:

        print("move left")
        player_x -= 1
        print("Player X: " + str(player_x))
        print("Player Y: " + str(player_y))

        player_location -= 4
        maze = maze.replace("o", " ")
        new_maze = maze[:player_location] + "o" + maze[(player_location + 1):]
        maze = new_maze

    elif str(press) == str("l") and phase == True:

        print("move right")
        player_x += 1
        print("Player X: " + str(player_x))
        print("Player Y: " + str(player_y))

        player_location += 4
        maze = maze.replace("o", " ")
        new_maze = maze[:player_location] + "o" + maze[(player_location + 1):]
        maze = new_maze

    else:
        print("Invalid input. Try again!")