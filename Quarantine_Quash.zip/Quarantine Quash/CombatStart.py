print("Welcome to your first combat!")
print("In just a moment, you'll be tasked with fighting your first hater!")
print("But first, let's get you caught up on the basics!")
print("First thing's first, combat functions similarly to Rock, Paper, Scissors, instead, Bash, Strike, Dodge.")
print("Bash beats Dodge, Dodge beats Strike, and Strike beats Bash!")
print("You will input the number 1 for Bash, the number 2 for Dodge, and the number 3 for Strike")
print("Let's practice, would you like to Bash, Dodge, or Strike?")
TutorialChoice = int(input())
if TutorialChoice == 1:
    print("You chose to bash! Congratulations, you're ready to fight the haters!")
    exec(open("FirstHater.py").read());
elif TutorialChoice == 2:
    print("You chose to dodge! Congratulations, you're ready to fight the haters!")
    exec(open("FirstHater.py").read());
elif TutorialChoice == 3:
    print("You chose to strike! Congratulations, you're ready to fight the haters!")
    exec(open("FirstHater.py").read());
else:
    print("""
    
    
    """)
    print("That isn't an option, try again!")
    exec(open("CombatStart.py").read());
