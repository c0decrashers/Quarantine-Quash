import random

Troll1 = 5
PlayerHP = 4
tie_counter = 0
round_counter = 1

print("You have 4 lives, if you lose two rounds, you'll be returned to the start of the maze, stay safe!")

if character_selection == "3":
    print("""

Remember, trolls don't attack like normal haters, they attack every other turn, but \n they hit twice as hard! They also resist stronger attacks!
_________________________                       
|               /O\     |
|               \_/     |
|              /T-T\    |
|   o [|]       *!@     |
|   |--|        %$#     |  
|   |\ |        / \     |
\_______________________/

What will you do? Bash, Dodge, or Strike?
                   1      2         3""")
    while int(Troll1) > 0:
        moveChoice = input()
        if moveChoice == "Dab":
            print("""
                _________________________
                |               _____   |   
                |  <o/         { @!@ }  |
                |   |          / %$# \  | 
                |   |\         \ / \ /  |
                \_______________________/""")
            print("""
                _________________________
                |                       |   
                |  <o/            ==    |
                |   |             ||    | 
                |   |\            <>    |
                \_______________________/            
                            """)
            print("""

                _________________________                       
                |               /O\     |
                |               \_/     |
                |              /T-T\    |
                |   o [|]       *!@     |
                |   |--|        %$#     | 
                |   |\ |        / \     |
                \_______________________/

            """)
            print("You dabbed on the Troll and it was harmed!")
            Troll1 = Troll1 - 2
        elif int(moveChoice) == 1 or int(moveChoice) == 2 or int(moveChoice) == 3:
            moveChoice = int(moveChoice)
            if (int(round_counter) % 2) != 0:
                round_counter = round_counter + 1
                print("The troll is charging an attack, giving you a free attack")
                Troll1 = Troll1 - 1
            else:
                round_counter = round_counter + 1
                trollChoice = int(random.randint(1, 3))
                if moveChoice == trollChoice:
                    print("It was a tie")
                    tie_counter = tie_counter + 1
                    if tie_counter >= 10:
                        exec(open("QQEasterEgg.py").read())
                # Bash->Dodge
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 5:
                    print("You bashed the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 4:
                    print("You bashed the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 3:
                    print("You bashed the Troll, two more hits like that and it'll be done!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 2:
                    print("You bashed the troll, one more hit!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 1:
                    print("You bashed the troll!")
                    Troll1 = Troll1 - 1
                # Bash->Strike
                elif moveChoice == 1 and trollChoice == 3 and PlayerHP == 4:
                    print("You were struck by the troll, one more hit like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 1 and trollChoice == 3 and PlayerHP == 2:
                    print("You were struck by the troll, one more hit like that and you'll be sent back to the start!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the hater, too bad!")
                        exec(open("Death_Screen.py").read());
                # Dodge->Strike
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 5:
                    print("You dodged the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 4:
                    print("You dodged the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 3:
                    print("You dodged the troll, two more successes like that and it will fall!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 2:
                    print("You dodged the troll, one more success like that and it will fall!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 1:
                    print("You dodged the troll!")
                    Troll1 = Troll1 - 1
                # Dodge->Bash
                elif moveChoice == 2 and trollChoice == 1 and PlayerHP == 4:
                    print("You were bashed by the troll, one more hit like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 2 and trollChoice == 1 and PlayerHP == 2:
                    print("You were bashed by the troll!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the troll, too bad!")
                        exec(open("Death_Screen.py").read());
                # Strike->Bash
                elif moveChoice == 3 and trollChoice == 1 and Troll1 == 5:
                    print("You struck the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 4:
                    print("You struck the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 3:
                    print("You struck the Troll, two more hits like that and it'll be done!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 2:
                    print("You struck the troll, one more hit!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 1:
                    print("You struck the troll!")
                    Troll1 = Troll1 - 1
                # Strike->Dodge
                elif moveChoice == 3 and trollChoice == 2 and PlayerHP == 4:
                    print("You were dodged by the troll, one more failure like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 3 and trollChoice == 2 and PlayerHP == 2:
                    print("You were dodged by the troll!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the troll, too bad!")
                        exec(open("Death_Screen.py").read());
        else:
            print("That's not a proper input! Try again.")
    print("You have stopped your first Troll! Now, get back to the maze!")
    exec(open("Level_2_Troll2.py").read());

if character_selection == "1":
    print("""

Remember, trolls don't attack like normal haters, they attack every other turn, but \n they hit twice as hard! They also resist stronger attacks!
_________________________                       
|               /O\     |
|               \_/     |
|              /T-T\    |
|   o   __      *!@     | 
|   |--/  *     %$#     | 
|   |\          / \     |
\_______________________/

What will you do? Bash, Dodge, or Strike?
                   1      2         3""")
    while int(Troll1) > 0:
        moveChoice = input()
        if moveChoice == "Dab":
            print("You dabbed on the Troll and it was harmed!")
            print("""
                _________________________
                |               _____   |   
                |  <o/         { @!@ }  |
                |   |          / %$# \  | 
                |   |\         \ / \ /  |
                \_______________________/""")
            print("""
                _________________________
                |                       |   
                |  <o/                  |
                |   |           <(*)    | 
                |   |\           (__)   |
                \_______________________/
                            """)
            print("""

                _________________________                       
                |               /O\     |
                |               \_/     |
                |              /T-T\    |
                |   o   __      *!@     |
                |   |--/  *     %$#     | 
                |   |\          / \     |
                \_______________________/

            """)
            Troll1 = Troll1 - 2
        elif int(moveChoice) == 1 or int(moveChoice) == 2 or int(moveChoice) == 3:
            moveChoice = int(moveChoice)
            if (int(round_counter) % 2) != 0:
                round_counter = round_counter + 1
                print("The troll is charging an attack, giving you a free attack")
                Troll1 = Troll1 - 1
            else:
                round_counter = round_counter + 1
                trollChoice = int(random.randint(1, 3))
                if moveChoice == trollChoice:
                    print("It was a tie")
                    tie_counter = tie_counter + 1
                # Bash->Dodge
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 5:
                    print("You bashed the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 4:
                    print("You bashed the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 3:
                    print("You bashed the Troll, two more hits like that and it'll be done!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 2:
                    print("You bashed the troll, one more hit!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 1:
                    print("You bashed the troll!")
                    Troll1 = Troll1 - 1
                # Bash->Strike
                elif moveChoice == 1 and trollChoice == 3 and PlayerHP == 4:
                    print("You were struck by the troll, one more hit like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 1 and trollChoice == 3 and PlayerHP == 2:
                    print("You were struck by the troll, one more hit like that and you'll be sent back to the start!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the hater, too bad!")
                        exec(open("Death_Screen.py").read());
                # Dodge->Strike
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 5:
                    print("You dodged the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 4:
                    print("You dodged the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 3:
                    print("You dodged the troll, two more successes like that and it will fall!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 2:
                    print("You dodged the troll, one more success like that and it will fall!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 1:
                    print("You dodged the troll!")
                    Troll1 = Troll1 - 1
                # Dodge->Bash
                elif moveChoice == 2 and trollChoice == 1 and PlayerHP == 4:
                    print("You were bashed by the troll, one more hit like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 2 and trollChoice == 1 and PlayerHP == 2:
                    print("You were bashed by the troll!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the troll, too bad!")
                        exec(open("Death_Screen.py").read());
                # Strike->Bash
                elif moveChoice == 3 and trollChoice == 1 and Troll1 == 5:
                    print("You struck the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 4:
                    print("You struck the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 3:
                    print("You struck the Troll, two more hits like that and it'll be done!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 2:
                    print("You struck the troll, one more hit!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 1:
                    print("You struck the troll!")
                    Troll1 = Troll1 - 1
                # Strike->Dodge
                elif moveChoice == 3 and trollChoice == 2 and PlayerHP == 4:
                    print("You were dodged by the troll, one more failure like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 3 and trollChoice == 2 and PlayerHP == 2:
                    print("You were dodged by the troll!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the troll, too bad!")
                        exec(open("Death_Screen.py").read());
        else:
            print("That's not a proper input! Try again.")
    print("You have stopped your first Troll! Now, get back to the maze!")
    exec(open("Level_2_Troll2.py").read());

if character_selection == "2":
    print("""

Remember, trolls don't attack like normal haters, they attack every other turn, but \n they hit twice as hard! They also resist stronger attacks!
_________________________                       
|              /O\      |
|              \_/      |
|             /T-T\     |
|  ;o;|        *!@      |
|   |-t        %$#      | 
|   |\         / \      |
\_______________________/

What will you do? Bash, Dodge, or Strike?
                   1      2         3""")
    while int(Troll1) > 0:
        moveChoice = input()
        if moveChoice == "Dab":
            print("You dabbed on the Troll and it was harmed!")
            print("""
                _________________________
                |               _____   |   
                |  <o/         { @!@ }  |
                |   |          / %$# \  | 
                |   |\         \ / \ /  |
                \_______________________/""")
            print("""
                _________________________
                |                       |                           
                |  <o/            ==    |
                |   |             ||    | 
                |   |\            <>    |
                \_______________________/
                            """)
            print("""

                _________________________                       
                |               /O\     |
                |               \_/     |
                |              /T-T\    |
                |  ;o;|         *!@     |
                |   |-t         %$#     | 
                |   |\          / \     |
                \_______________________/

            """)
            Troll1 = Troll1 - 2
        elif int(moveChoice) == 1 or int(moveChoice) == 2 or int(moveChoice) == 3:
            moveChoice = int(moveChoice)
            if (int(round_counter) % 2) != 0:
                round_counter = round_counter + 1
                print("The troll is charging an attack, giving you a free attack")
                Troll1 = Troll1 - 1
            else:
                round_counter = round_counter + 1
                trollChoice = int(random.randint(1, 3))
                if moveChoice == trollChoice:
                    print("It was a tie")
                    tie_counter = tie_counter + 1
                    if tie_counter >= 10:
                        exec(open("QQEasterEgg.py").read())
                # Bash->Dodge
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 5:
                    print("You bashed the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 4:
                    print("You bashed the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 3:
                    print("You bashed the Troll, two more hits like that and it'll be done!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 2:
                    print("You bashed the troll, one more hit!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 1:
                    print("You bashed the troll!")
                    Troll1 = Troll1 - 1
                # Bash->Strike
                elif moveChoice == 1 and trollChoice == 3 and PlayerHP == 4:
                    print("You were struck by the troll, one more hit like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 1 and trollChoice == 3 and PlayerHP == 2:
                    print("You were struck by the troll, one more hit like that and you'll be sent back to the start!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the hater, too bad!")
                        exec(open("Death_Screen.py").read());
                # Dodge->Strike
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 5:
                    print("You dodged the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 4:
                    print("You dodged the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 3:
                    print("You dodged the troll, two more successes like that and it will fall!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 2:
                    print("You dodged the troll, one more success like that and it will fall!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 2 and trollChoice == 3 and Troll1 == 1:
                    print("You dodged the troll!")
                    Troll1 = Troll1 - 1
                # Dodge->Bash
                elif moveChoice == 2 and trollChoice == 1 and PlayerHP == 4:
                    print("You were bashed by the troll, one more hit like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 2 and trollChoice == 1 and PlayerHP == 2:
                    print("You were bashed by the troll!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the troll, too bad!")
                        exec(open("Death_Screen.py").read());
                # Strike->Bash
                elif moveChoice == 3 and trollChoice == 1 and Troll1 == 5:
                    print("You struck the troll, it'll take much more than that to slay this beast!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 4:
                    print("You struck the troll, you're getting closer!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 3:
                    print("You struck the Troll, two more hits like that and it'll be done!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 2:
                    print("You struck the troll, one more hit!")
                    Troll1 = Troll1 - 1
                elif moveChoice == 1 and trollChoice == 2 and Troll1 == 1:
                    print("You struck the troll!")
                    Troll1 = Troll1 - 1
                # Strike->Dodge
                elif moveChoice == 3 and trollChoice == 2 and PlayerHP == 4:
                    print("You were dodged by the troll, one more failure like that and you will fall!")
                    PlayerHP = PlayerHP - 2
                elif moveChoice == 3 and trollChoice == 2 and PlayerHP == 2:
                    print("You were dodged by the troll!")
                    PlayerHP = PlayerHP - 2
                    if PlayerHP == 0:
                        print("You were slain by the troll, too bad!")
                        exec(open("Death_Screen.py").read());
        else:
            print("That's not a proper input! Try again.")
    print("You have stopped your first Troll! Now, get back to the maze!")
    exec(open("Level_2_Troll2.py").read());
