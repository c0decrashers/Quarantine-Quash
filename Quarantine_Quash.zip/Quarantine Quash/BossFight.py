import random

dodgeCounter = 0
RonaHP = 3

if character_selection == "1":
    print("""
    
    --------------------------------------------------------------------
    |                                                                  |
    |                                                                  |
    |                                                  o   o  o        |
    |                                              o   _\__|__|_   o   |
    |                                               \_/         \_/    |
    |                                            o  /   \   /     \  o |
    |                                             \/   O     O     \/  |
    |                                              |               |_o |
    |                                            o-|     ___       |   |
    |                                              |    /v v\      |-o |
    |                                            o_\    \___/      /   |
    |                                               \_           _/\   |
    |                                                /\_________/   o  |
    |                                               o  /   |  \        | 
    |   o   __                                        o    o   o       |
    |   |--/  *                                                        |
    |   |\                                                             |
    |__________________________________________________________________|
    
    Welcome to the final boss, the Rona, master of Deceit and Loneliness.
    This fight will function differently, as you will have to dodge the attacks of the Snake with your maze movement.
    One wrong move and you'll be sent right back to the start. After dodging enough attacks, the Rona will become \n vulnerable enough for you to damage him.
    You need to repeat this process 3 times to slay the creature, unless you have the Easter Egg.
    Good Luck Quasher, may your dodging skills be prominent.
    """)
    Continue = input("Hit enter to continue")
    while RonaHP > 0:
        while dodgeCounter < 5:
            BossAttack = random.randint(1, 5)
            if BossAttack == 1:
                #Spikes-Vertical (d)
                print("""
        
                        --------------------------------------------------------------------
                        |  ||         ||         ||                                        |
                        |  ||         ||         ||                                        |
                        |  \/         \/         \/                        o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                            o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |   o   __                                        o    o   o       |
                        |   |--/  *                                                        |
                        |   |\                                                             |
                        |__________________________________________________________________|
                    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "d":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "w" or "a" or "s":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 2:
                # Spikes-Horizontal-Above (s)
                print("""
                        --------------------------------------------------------------------
                        |                                                                  |
                        |                                                                  |
                        |                                                  o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                     <===== o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                   <=====   o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                     <=====    \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |   o   __                                 <===== o    o   o       |
                        |   |--/  *                                                        |
                        |   |\                                                             |
                        |__________________________________________________________________|
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "s":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "w" or "a" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 3:
                #Spikes-Horizontal-Below
                print("""
    
                        --------------------------------------------------------------------
                        |                                                                  |
                        |                                                                  |
                        |                                                  o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                     <===== o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                   <=====   o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                     <=====    \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |   o   __                                        o    o   o       |
                        |   |--/  *                                           //           |
                        |   |\                                        <=====_//            |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "w":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "a" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 4:
                #Spikes-Vertical-Right
                print("""
                        --------------------------------------------------------------------
                        |      ||         ||         ||                                    |
                        |      ||         ||         ||                                    |
                        |      \/         \/         \/                    o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                            o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        |
                        |   o   __                                        o    o   o       |
                        |   |--/  *                                                        |
                        |   |\                                                             |
                        |__________________________________________________________________|
                        
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "a":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "w" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 5:
                print("""
                        --------------------------------------------------------------------
                        |\\                 ||      ||      ||                             |
                        | \\                ||      ||      ||                             |
                        |  \\               \/      \/      \/             o   o  o        |
                        |   \\                                         o   _\__|__|_   o   |
                        |                                        <===== \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                       <===== |               |_o |
                        |                                            o-|     ___       |   |
                        |                                       <===== |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                        <=====  /\_________/   o  |
                        |>                                              o  /   |  \        |
                        |>   o   __                                       o    o   o       |
                        |>   |--/  *                                                       |
                        |>   |\     <> <> <> <> <> <>                                      |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                                """)
                Dodge = input()
                if Dodge == "":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "w" or "d" or "a":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")

        print("""
    
        --------------------------------------------------------------------
        |                                                                  |
        |                                                                  |
        |                                                  o   o  o        |
        |                                              o   _\__|__|_   o   |
        |                                               \_/         \_/    |
        |                                            o  /   \   /     \  o |
        |                                             \/   O     O     \/  |
        |                                              |          []   |_o |
        |                                            o-|     ___   \   |   |
        |                                              |    /v v\      |-o |
        |                                            o_\    \___/      /   |
        |                                               \_           _/\   |
        |                                                /\_________/   o  |
        |                                               o  /   |  \        |
        |   o   __                                        o    o   o       |
        |   |--/  *                                                        |
        |   |\                                                             |
        |__________________________________________________________________|
        
        Now's your chance! Strike the Rona (enter)!
    
        """)
        ronaStrike = input()
        if ronaStrike == "":
            print("You've successfully damaged the Rona!")
            RonaHP = RonaHP - 1
            dodgeCounter = 0
            ronaStrike = "none"
        elif ronaStrike == "Dab":
            print("You've dabbed on the Rona!")
            RonaHP = RonaHP - 3
    print("Dealing your final powerful blow to the Rona, the ultimate hater, you feel bolstered \n you step out into another day, free of has, trolls, and the Rona itself.")
    exec(open("dead_rona.py").read());
elif character_selection == "2":
    print("""

        --------------------------------------------------------------------
        |                                                                  |
        |                                                                  |
        |                                                  o   o  o        |
        |                                              o   _\__|__|_   o   |
        |                                               \_/         \_/    |
        |                                            o  /   \   /     \  o |
        |                                             \/   O     O     \/  |
        |                                              |               |_o |
        |                                            o-|     ___       |   |
        |                                              |    /v v\      |-o |
        |                                            o_\    \___/      /   |
        |                                               \_           _/\   |
        |                                                /\_________/   o  |
        |                                               o  /   |  \        | 
        |  ;o;|                                          o    o   o        |
        |   |-t                                                            |
        |   |\                                                             |
        |__________________________________________________________________|

        Welcome to the final boss, the Rona, master of Deceit and Loneliness.
        This fight will function differently, as you will have to dodge the attacks of the Snake with your maze movement.
        One wrong move and you'll be sent right back to the start. After dodging enough attacks, the Rona will become \n vulnerable enough for you to damage him.
        You need to repeat this process 3 times to slay the creature, unless you have the Easter Egg.
        Good Luck Quasher, may your dodging skills be prominent.

        """)
    Continue = input("Hit enter to continue")
    while RonaHP > 0:
        while dodgeCounter < 5:
            BossAttack = random.randint(1, 5)
            if BossAttack == 1:
                # Spikes-Vertical (d)
                print("""
    
                        --------------------------------------------------------------------
                        |  ||         ||         ||                                        |
                        |  ||         ||         ||                                        |
                        |  \/         \/         \/                        o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                            o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |  ;o;|                                           o    o   o       |
                        |   |-t                                                            |
                        |   |\                                                             |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "d":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "w" or "a" or "s":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 2:
                # Spikes-Horizontal-Above (s)
                print("""
                        --------------------------------------------------------------------
                        |                                                                  |
                        |                                                                  |
                        |                                                  o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                     <===== o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                   <=====   o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                     <=====    \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |  ;o;|                                    <===== o    o   o       |
                        |   |-t                                                            |
                        |   |\                                                             |
                        |__________________________________________________________________|
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "s":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "w" or "a" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 3:
                # Spikes-Horizontal-Below
                print("""
    
                        --------------------------------------------------------------------
                        |                                                                  |
                        |                                                                  |
                        |                                                  o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                     <===== o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                   <=====   o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                     <=====    \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |  ;o;|                                           o    o   o       |
                        |   |-t                                               //           |
                        |   |\                                        <=====_//            |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "w":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "a" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 4:
                # Spikes-Vertical-Right
                print("""
                        --------------------------------------------------------------------
                        |      ||         ||         ||                                    |
                        |      ||         ||         ||                                    |
                        |      \/         \/         \/                    o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                            o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |  ;o;|                                           o    o   o       |
                        |   |-t                                                            |
                        |   |\                                                             |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "a":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "w" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 5:
                print("""
                        --------------------------------------------------------------------
                        |\\                 ||      ||      ||                             |
                        | \\                ||      ||      ||                             |
                        |  \\               \/      \/      \/             o   o  o        |
                        |   \\                                         o   _\__|__|_   o   |
                        |                                        <===== \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                       <===== |               |_o |
                        |                                            o-|     ___       |   |
                        |                                       <===== |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                        <=====  /\_________/   o  |
                        |>                                              o  /   |  \        | 
                        |>  ;o;|                                          o    o   o       |
                        |>   |-t                                                           |
                        |>   |\  <> <> <> <> <> <>                                         |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                                """)
                Dodge = input()
                if Dodge == "":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "w" or "d" or "a":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")

        print("""
    
        --------------------------------------------------------------------
        |                                                                  |
        |                                                                  |
        |                                                  o   o  o        |
        |                                              o   _\__|__|_   o   |
        |                                               \_/         \_/    |
        |                                            o  /   \   /     \  o |
        |                                             \/   O     O     \/  |
        |                                              |          []   |_o |
        |                                            o-|     ___   \   |   |
        |                                              |    /v v\      |-o |
        |                                            o_\    \___/      /   |
        |                                               \_           _/\   |
        |                                                /\_________/   o  |
        |                                               o  /   |  \        | 
        |  ;o;|                                           o    o   o       |
        |   |-t                                                            |
        |   |\                                                             |
        |__________________________________________________________________|
    
        Now's your chance! Strike the Rona (enter)!
    
        """)
        ronaStrike = input()
        if ronaStrike == "":
            print("You've successfully damaged the Rona!")
            RonaHP = RonaHP - 1
            dodgeCounter = 0
            ronaStrike = "none"
        elif ronaStrike == "Dab":
            print("You've dabbed on the Rona!")
            RonaHP = RonaHP - 3
    print("Dealing your final powerful blow to the Rona, the ultimate hater, you feel bolstered \n you step out into another day, free of haters, trolls, and the Rona itself.")
    exec(open("dead_rona.py").read());

elif character_selection == "3":
    print("""

            --------------------------------------------------------------------
            |                                                                  |
            |                                                                  |
            |                                                  o   o  o        |
            |                                              o   _\__|__|_   o   |
            |                                               \_/         \_/    |
            |                                            o  /   \   /     \  o |
            |                                             \/   O     O     \/  |
            |                                              |               |_o |
            |                                            o-|     ___       |   |
            |                                              |    /v v\      |-o |
            |                                            o_\    \___/      /   |
            |                                               \_           _/\   |
            |                                                /\_________/   o  |
            |                                               o  /   |  \        | 
            |   o [|]                                         o    o   o       |
            |   |--|                                                           |
            |   |\ |                                                           |
            |__________________________________________________________________|

            Welcome to the final boss, the Rona, master of Deceit and Loneliness.
            This fight will function differently, as you will have to dodge the attacks of the Snake with your maze movement.
            One wrong move and you'll be sent right back to the start. After dodging enough attacks, the Rona will become \n vulnerable enough for you to damage him.
            You need to repeat this process 3 times to slay the creature, unless you have the Easter Egg.
            Good Luck Quasher, may your dodging skills be prominent.

            """)
    Continue = input("Hit enter to continue")
    while RonaHP > 0:
        while dodgeCounter < 5:
            BossAttack = random.randint(1, 5)
            if BossAttack == 1:
                # Spikes-Vertical (d)
                print("""
    
                        --------------------------------------------------------------------
                        |  ||         ||         ||                                        |
                        |  ||         ||         ||                                        |
                        |  \/         \/         \/                        o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                            o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |   o [|]                                         o    o   o       |
                        |   |--|                                                           |
                        |   |\ |                                                           |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "d":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "w" or "a" or "s":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 2:
                # Spikes-Horizontal-Above (s)
                print("""
                        --------------------------------------------------------------------
                        |                                                                  |
                        |                                                                  |
                        |                                                  o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                     <===== o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                   <=====   o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                     <=====    \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |   o [|]                                  <===== o    o   o       |
                        |   |--|                                                           |
                        |   |\ |                                                            |
                        |__________________________________________________________________|
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "s":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "w" or "a" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 3:
                # Spikes-Horizontal-Below
                print("""
    
                        --------------------------------------------------------------------
                        |                                                                  |
                        |                                                                  |
                        |                                                  o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                     <===== o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                   <=====   o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                     <=====    \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |   o [|]                                         o    o   o       |
                        |   |--|                                             //            |
                        |   |\ |                                     <=====_//             |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "w":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "a" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 4:
                # Spikes-Vertical-Right
                print("""
                        --------------------------------------------------------------------
                        |      ||         ||         ||                                    |
                        |      ||         ||         ||                                    |
                        |      \/         \/         \/                    o   o  o        |
                        |                                              o   _\__|__|_   o   |
                        |                                               \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                              |               |_o |
                        |                                            o-|     ___       |   |
                        |                                              |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                                /\_________/   o  |
                        |                                               o  /   |  \        | 
                        |   o [|]                                         o    o   o       |
                        |   |--|                                                           |
                        |   |\ |                                                           |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                    """)
                Dodge = input()
                if Dodge == "a":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "w" or "d":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")
            elif BossAttack == 5:
                print("""
                        --------------------------------------------------------------------
                        |\\                 ||      ||      ||                             |
                        | \\                ||      ||      ||                             |
                        |  \\               \/      \/      \/             o   o  o        |
                        |   \\                                         o   _\__|__|_   o   |
                        |                                        <===== \_/         \_/    |
                        |                                            o  /   \   /     \  o |
                        |                                             \/   O     O     \/  |
                        |                                       <===== |               |_o |
                        |                                            o-|     ___       |   |
                        |                                       <===== |    /v v\      |-o |
                        |                                            o_\    \___/      /   |
                        |                                               \_           _/\   |
                        |                                        <=====  /\_________/   o  |
                        |>                                              o  /   |  \        | 
                        |>   o [|]                                        o    o   o       |
                        |>   |--|                                                          |
                        |>   |\ |   <> <> <> <> <> <>                                      |
                        |__________________________________________________________________|
    
                        Quick! Dodge out of the way with w, a, s, or d, or don't dodge at all (enter)!
                                """)
                Dodge = input()
                if Dodge == "":
                    print("You dodged the spikes!")
                    dodgeCounter = dodgeCounter + 1
                elif Dodge == "s" or "w" or "d" or "a":
                    print("You failed to dodge the spikes, you have been slain by the Rona.")
                    exec(open("Death_Screen.py").read());
                else:
                    print("Invalid input, try again!")

        print("""
    
        --------------------------------------------------------------------
        |                                                                  |
        |                                                                  |
        |                                                  o   o  o        |
        |                                              o   _\__|__|_   o   |
        |                                               \_/         \_/    |
        |                                            o  /   \   /     \  o |
        |                                             \/   O     O     \/  |
        |                                              |          []   |_o |
        |                                            o-|     ___   \   |   |
        |                                              |    /v v\      |-o |
        |                                            o_\    \___/      /   |
        |                                               \_           _/\   |
        |                                                /\_________/   o  |
        |                                               o  /   |  \        | 
        |   o [|]                                         o    o   o       |
        |   |--|                                                           |
        |   |\ |                                                           |
        |__________________________________________________________________|
    
        Now's your chance! Strike the Rona (enter))!
    
        """)
        ronaStrike = input()
        if ronaStrike == "":
            print("You've successfully damaged the Rona!")
            RonaHP = RonaHP - 1
            dodgeCounter = 0
            ronaStrike = "none"
        elif ronaStrike == "Dab":
            print("You've dabbed on the Rona!")
            RonaHP = RonaHP - 3
    print("Dealing your final powerful blow to the Rona, the ultimate hater, you feel bolstered \n you step out into another day, free of haters, trolls, and the Rona itself.")
    exec(open("dead_rona.py").read());