print("""
\        /   _________     ________    _______    _____      ______    \     /    |
 \      /        |        /        \      |      /     \    |      \    \   /     |
  \    /         |       |                |     |       |   |______/     \ /      |
   \  /          |       |                |     |       |   |      \      |       |
    \/       ____|____    \________/      |      \_____/    |       \     |       o
                                                                                     
                           
              Congrats! This is the end of the game. We hope you enjoyed.
            If you haven't seen the easter egg, you can always play again.
            
                         o>  __     ;o;|         o [|]
                         |--/  *     |-t         |--|
                         |\          |\          |\ |
                                       
                               
                                
                                Quarantine Quash             
                           Made By the c0decrashers!
""")

Playagain = input("To play again, hit enter")

if str(Playagain) == str():
    exec(open("Intro_Screen.py").read())

