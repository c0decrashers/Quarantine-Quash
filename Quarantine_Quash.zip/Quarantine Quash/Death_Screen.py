print("""
 _______        _______      ________      _______         /\        ___________
|       \      |            |             |               /  \            |
|        \     |            |             |              /    \           |
|         |    |-------     |--------     |-------      /______\          |
|        /     |            |             |            /        \         |
|_______/      |_______     |             |_______    /          \        |


                                |     
                 You Failed. Congrats. Try again

""")
Playagain = input("To play again, hit enter")

if str(Playagain) == str():
    exec(open("input_movement.py").read());
