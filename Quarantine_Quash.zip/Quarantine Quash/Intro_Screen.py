import random
random
print("""


""")
Playername = input("     Enter your name: ")
print("""


""")
print("     Welcome to Quarantine Quash, " + Playername + "!")
main = "                            \n                              \n                              \n                              \n               Quarantine              \n                 Quash                 \n                                       \n                                       \n                                       \n                                       "
print(main)

start = input("           Hit enter to start")
print("""



     
     
     
















 """)
# Charater Seletion 1,2,3

print("Choose Your Character")
characters = """[1]         [2]         [3]
 o   __     ;o;|         o [|]
 |--/  *     |-t         |--|
 |\          |\          |\ | 
 Type 1, 2, or 3 (no selection crashes the game)


 """
print(characters)
character_selection = input("Selection |  ")
print("""





















""")
if str(character_selection) == str(1):
    print("""You have Chosen Hunter!
       o   __
       |--/  *
       |\ 
This is the hero you have chosen for the game.



""")

elif str(character_selection) == str(2):
    print("""You Have Chosen Colin!
       ;o;|
        |-t
        |\ 
 This is the hero you have chosen for the game.
 
 
 
 """)

elif str(character_selection) == str(3):
    print("""You Have Chosen Zack!
        o [|]
        |--|
        |\ |
This is the hero you have chosen for the game.



""")
else:
    exec(open("Intro Screen.py").read())

Continue = input("""Hit Enter to Continue""")
print("""

















 """)

# Controls/Rules
print("""
Controls and Rules
-----------------------------------------------------------
        W
1) Use ASD to input movement then hit enter to act on it. 
2) Use 1, 2 or 3 during combat to dab on the haters B).
-----------------------------------------------------------""")
print("""














 """)
Continue = input("""Hit Enter to Continue""")

print("""


























 """)
# Story Intro/Scenario Intro
print("""In the world of Quarantine...the internet is full of trolls and haters. 
The only way out; an elaborate maze. You will face many challenges. 
You will face many trolls, many haters. But if you do, strike them down with great force. 
You will be handsomely rewarded. This is...""")
print("                                                                                 ")
Continue = input("""Hit Enter to Continue""")
print("""

























""")
print("""QUARANTINE QUASH!!


P.S. There is a tale of a hidden easter egg under the combat's code. Find it and you will be greatly rewarded.
""")

Continue = input("""Hit Enter to Continue""")

exec(open("input_movement.py").read());