player_x_3 = 9
player_y_3 = 1
in_combat = False
phase = False
met_rona = False
room = """
 _______________________________\ _ /_______________________________ 
|   |       |       |       |   | o |   |       |       |       |   |
|   |___    |       |    ___|   |   |   |___    |       |    ___|   |
|       |   |       |   |       |   |       |   |       |   |       |
|       |   |       |   |       |   |       |   |       |   |       |
|       |   |       |   |       |   |       |   |       |   |       |
|    ___|   |       |   |___    |   |    ___|   |       |   |___    |
|   |       |       |       |   |   |   |       |       |       |   |
|___|_______|_______|_______|___|   |___|_______|_______|_______|___|
|   |                                                           |   |
|   |                                                           |   |
|   |                                                           |   |
|   |                                                           |   |
|   |                         O   O  O                          |   |
|   |                     O   _\__|__|_   O                     |   |
|   |                      \_/         \_/                      |   |
|   |                   O  /             \  O                   |   |
|   |                    \/               \/                    |   |
|   |                     |               |_O                   |   |
|   |                   O_\               /                     |   |
|   |                      \_  O     O  _/\                     |   |
|   |                       /\_________/   O                    |   |
|   |                      O  /   |  \                          |   |
|   |                        O    O   O                         |   |
|___|___________________________________________________________|___|
"""

while not in_combat:

#maze
    print(room)
    player_location = room.find("o")

#encounters
    if player_y_3 == 5 and met_rona == False:
        met_rona = True
        room = """
         _______________________________\ _ /_______________________________ 
        |   |       |       |       |   |   |   |       |       |       |   |
        |   |___    |       |    ___|   |   |   |___    |       |    ___|   |
        |       |   |       |   |       |   |       |   |       |   |       |
        |       |   |       |   |       |   |       |   |       |   |       |
        |       |   |       |   |       |   |       |   |       |   |       |
        |    ___|   |       |   |___    |   |    ___|   |       |   |___    |
        |   |       |       |       |   |   |   |       |       |       |   |
        |___|_______|_______|_______|___|   |___|_______|_______|_______|___|
        |   |                             o                             |   |
        |   |                                                           |   |
        |   |                                                           |   |
        |   |                                                           |   |
        |   |                         O   O    O                        |   |
        |   |                         _\__|___/  O                      |   |
        |   |                    O  _/         \/                       |   |
        |   |                     \/   O     O   \_O                    |   |
        |   |                     /    /     \    \                     |   |
        |   |                   O-|               |                     |   |
        |   |                    /\               /\                    |   |
        |   |                   O  \_           _/  O                   |   |
        |   |                      / \_________/ \                      |   |
        |   |                     O    |  |  \    O                     |   |
        |   |                          O  O   O                         |   |
        |___|___________________________________________________________|___|
        """
        print(room)

#input movement
    press = input("")
    if str(press) == str("w") and room[player_location - 71] != "_":

        if met_rona:
            exec(open("BossFight.py").read())

        print("move up")
        player_y_3 -= 1
        print("Player X: " + str(player_x_3))
        print("Player Y: " + str(player_y_3))

        player_location -= 140
        room = room.replace("o", " ")
        new_maze = room[:player_location] + "o" + room[(player_location + 1):]
        room = new_maze

    elif str(press) == str("s") and room[player_location + 71] != "_":

        if met_rona:
            exec(open("BossFight.py").read())

        print("move down")
        player_y_3 += 1
        print("Player X: " + str(player_x_3))
        print("Player Y: " + str(player_y_3))

        player_location += 140
        room = room.replace("o", " ")
        new_maze = room[:player_location] + "o" + room[(player_location + 1):]
        room = new_maze

    elif str(press) == str("a") and room[player_location - 2] != "|":

        if met_rona:
            exec(open("BossFight.py").read())

        print("move left")
        player_x_3 -= 1
        print("Player X: " + str(player_x_3))
        print("Player Y: " + str(player_y_3))

        player_location -= 4
        room = room.replace("o", " ")
        new_maze = room[:player_location] + "o" + room[(player_location + 1):]
        room = new_maze

    elif str(press) == str("d") and room[player_location + 2] != "|":

        if met_rona:
            exec(open("BossFight.py").read())

        print("move right")
        player_x_3 += 1
        print("Player X: " + str(player_x_3))
        print("Player Y: " + str(player_y_3))

        player_location += 4
        room = room.replace("o", " ")
        new_maze = room[:player_location] + "o" + room[(player_location + 1):]
        room = new_maze

    elif str(press) == str("togglephase"):

        print("phase activated!")
        phase = True

    elif str(press) == str("i") and phase == True:

        if met_rona:
            exec(open("BossFight.py").read())

        print("move up")
        player_y_3 -= 1
        print("Player X: " + str(player_x_3))
        print("Player Y: " + str(player_y_3))

        player_location -= 140
        room = room.replace("o", " ")
        new_maze = room[:player_location] + "o" + room[(player_location + 1):]
        room = new_maze

    elif str(press) == str("k") and phase == True:

        if met_rona:
            exec(open("BossFight.py").read())

        print("move down")
        player_y_3 += 1
        print("Player X: " + str(player_x_3))
        print("Player Y: " + str(player_y_3))

        player_location += 140
        room = room.replace("o", " ")
        new_maze = room[:player_location] + "o" + room[(player_location + 1):]
        room = new_maze

    elif str(press) == str("j") and phase == True:

        if met_rona:
            exec(open("BossFight.py").read())

        print("move left")
        player_x_3 -= 1
        print("Player X: " + str(player_x_3))
        print("Player Y: " + str(player_y_3))

        player_location -= 4
        room = room.replace("o", " ")
        new_maze = room[:player_location] + "o" + room[(player_location + 1):]
        room = new_maze

    elif str(press) == str("l") and phase == True:

        if met_rona:
            exec(open("BossFight.py").read())

        print("move right")
        player_x_3 += 1
        print("Player X: " + str(player_x_3))
        print("Player Y: " + str(player_y_3))

        player_location += 4
        room = room.replace("o", " ")
        new_maze = room[:player_location] + "o" + room[(player_location + 1):]
        room = new_maze

    else:
        print("Invalid input. Try again!")