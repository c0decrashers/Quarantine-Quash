player_x_2 = 9
player_y_2 = 1
in_combat = False
phase = False
maze_2 = """
 _______________________________/ _ \_______________________________ 
|                       |         o     |           |       |       |
|    ___     ___     ___|    ___________|    ___    |       |       |
|   |   |   |   |       |   |           |   |       |   |       |   |
|   |   |   |   |___    T   |    ___    |   T       |___|_______|   |
|   |       |           |           |       |   |               |   |
|   |_______|____\_____*|___________|_______|   |___/______*    |   |
|   |                       |           |   |       |   |           |
|   |___     _______        |           |   |___    |   |    ___\___|
|           |           |       |   |       |           |   |       |
|___     ___|___     ___|    ___|___|    ___|_______    |___|       |
|   |   |       |       |   |           |           |           |   |
|   T   |       |_______|   |___/_______|    ___    ||______/___|   |
|   |       | G         |       |               | G                 |
|   |_______|    ___    |___    |    _______    |\______*___/__*    |
|                   |       |   |   |       |   |   |           |   |
|_______         ___|___    |   |___|       |   |   |    ___    |   |
|   |       |   |       |   |           |       |       |   |       |
|   |    ___|   |       T   |    _______|___    |_______|   |    ___|
|           |       |   |   |   |           |       |   |       |   |
|/__*______*|    ___|___|   |___|    ___    |___    |   |    ___|   |
|   |           |       |       |   |       |   |       |           |
|   |    _______|       |       |   |    ___|   |___    T_______    |
|   |   |       |   |       |   |   |   |               |       |   |
|   |   |       |   |_______|___|   T   |_______     ___|    ___|   |
|       |   |   |                   |       |           |       |   |
|    ___|   |___|______\________/__*|___    |    _______|___    |   |
|   |   |               |       |       |   |           |           |
|   |   |    _______    |___    T       |   |_______    |    _______|
|   |       |               |   |   |       |   |       |           |
|   T_______|    _______    |   |   |_______|   |       |_______    |
|   |           |           |   |   |       |       |       |   |   |
|   |    _______|        ___T   |   |    ___|___    |___    |   |   |
|       |           |           |   |               |       |       |
|_______|/______*___|*_____*_\__|/ \|___*___/__/*__\|_______T_______|
"""

#haters
troll_13_7 = True
troll_2 = True
troll_2_x = 4
troll_2_y = 7
troll_2_location = maze_2.find("G", 0, 930)
troll_2_movement = 140

while not in_combat:

#maze
    print(maze_2)
    if maze_2[troll_2_location + 70] == "_":
        troll_2_movement = -140
    elif maze_2[troll_2_location - 70] == "_":
        troll_2_movement = 140
    player_location = maze_2.find("o")

#encounters
    if player_y_2 == 18:
        player_y_2 = 0
        exec(open("boss_room.py").read())

    if player_x_2 == 13 and player_y_2 == 7 and troll_13_7 == True:
        troll_13_7 = False
        exec(open("FirstTroll.py").read())

    if player_x_2 == troll_2_x and player_y_2 == troll_2_y and troll_2 == True:
        troll_2 = False
        exec(open("SecondTroll").read())

#input movement
    press = input("")
    if str(press) == str("w") and maze_2[player_location - 71] != "_":

        print("move up")
        player_y_2 -= 1
        print("Player X: " + str(player_x_2))
        print("Player Y: " + str(player_y_2))

        player_location -= 140
        maze_2 = maze_2.replace("o", " ")
        new_maze = maze_2[:player_location] + "o" + maze_2[(player_location + 1):]
        maze_2 = new_maze

        maze_2 = maze_2[:troll_2_location] + " " + maze_2[(troll_2_location + 1):]
        troll_2_location += troll_2_movement
        maze_2 = maze_2[:troll_2_location] + "G" + maze_2[(troll_2_location + 1):]

    elif str(press) == str("s") and maze_2[player_location + 71] != "_":

        print("move down")
        player_y_2 += 1
        print("Player X: " + str(player_x_2))
        print("Player Y: " + str(player_y_2))

        player_location += 140
        maze_2 = maze_2.replace("o", " ")
        new_maze = maze_2[:player_location] + "o" + maze_2[(player_location + 1):]
        maze_2 = new_maze

        maze_2 = maze_2[:troll_2_location] + " " + maze_2[(troll_2_location + 1):]
        troll_2_location += troll_2_movement
        maze_2 = maze_2[:troll_2_location] + "G" + maze_2[(troll_2_location + 1):]

    elif str(press) == str("a") and maze_2[player_location - 2] != "|":

        print("move left")
        player_x_2 -= 1
        print("Player X: " + str(player_x_2))
        print("Player Y: " + str(player_y_2))

        player_location -= 4
        maze_2 = maze_2.replace("o", " ")
        new_maze = maze_2[:player_location] + "o" + maze_2[(player_location + 1):]
        maze_2 = new_maze

        maze_2 = maze_2[:troll_2_location] + " " + maze_2[(troll_2_location + 1):]
        troll_2_location += troll_2_movement
        maze_2 = maze_2[:troll_2_location] + "G" + maze_2[(troll_2_location + 1):]

    elif str(press) == str("d") and maze_2[player_location + 2] != "|":

        print("move right")
        player_x_2 += 1
        print("Player X: " + str(player_x_2))
        print("Player Y: " + str(player_y_2))

        player_location += 4
        maze_2 = maze_2.replace("o", " ")
        new_maze = maze_2[:player_location] + "o" + maze_2[(player_location + 1):]
        maze_2 = new_maze

        maze_2 = maze_2[:troll_2_location] + " " + maze_2[(troll_2_location + 1):]
        troll_2_location += troll_2_movement
        maze_2 = maze_2[:troll_2_location] + "G" + maze_2[(troll_2_location + 1):]

    elif str(press) == str("togglephase"):

        print("phase activated!")
        phase = True

    elif str(press) == str("i") and phase == True:

        print("move up")
        player_y_2 -= 1
        print("Player X: " + str(player_x_2))
        print("Player Y: " + str(player_y_2))

        player_location -= 140
        maze_2 = maze_2.replace("o", " ")
        new_maze = maze_2[:player_location] + "o" + maze_2[(player_location + 1):]
        maze_2 = new_maze

        maze_2 = maze_2[:troll_2_location] + " " + maze_2[(troll_2_location + 1):]
        troll_2_location += troll_2_movement
        maze_2 = maze_2[:troll_2_location] + "G" + maze_2[(troll_2_location + 1):]

    elif str(press) == str("k") and phase == True:

        print("move down")
        player_y_2 += 1
        print("Player X: " + str(player_x_2))
        print("Player Y: " + str(player_y_2))

        player_location += 140
        maze_2 = maze_2.replace("o", " ")
        new_maze = maze_2[:player_location] + "o" + maze_2[(player_location + 1):]
        maze_2 = new_maze

        maze_2 = maze_2[:troll_2_location] + " " + maze_2[(troll_2_location + 1):]
        troll_2_location += troll_2_movement
        maze_2 = maze_2[:troll_2_location] + "G" + maze_2[(troll_2_location + 1):]

    elif str(press) == str("j") and phase == True:

        print("move left")
        player_x_2 -= 1
        print("Player X: " + str(player_x_2))
        print("Player Y: " + str(player_y_2))

        player_location -= 4
        maze_2 = maze_2.replace("o", " ")
        new_maze = maze_2[:player_location] + "o" + maze_2[(player_location + 1):]
        maze_2 = new_maze

        maze_2 = maze_2[:troll_2_location] + " " + maze_2[(troll_2_location + 1):]
        troll_2_location += troll_2_movement
        maze_2 = maze_2[:troll_2_location] + "G" + maze_2[(troll_2_location + 1):]

    elif str(press) == str("l") and phase == True:

        print("move right")
        player_x_2 += 1
        print("Player X: " + str(player_x_2))
        print("Player Y: " + str(player_y_2))

        player_location += 4
        maze_2 = maze_2.replace("o", " ")
        new_maze = maze_2[:player_location] + "o" + maze_2[(player_location + 1):]
        maze_2 = new_maze

        maze_2 = maze_2[:troll_2_location] + " " + maze_2[(troll_2_location + 1):]
        troll_2_location += troll_2_movement
        maze_2 = maze_2[:troll_2_location] + "G" + maze_2[(troll_2_location + 1):]

    else:
        print("Invalid input. Try again!")