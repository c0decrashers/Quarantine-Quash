print("You found the Easter Egg! Congratulations! Now, for the fruits of your labor")
print("If you input 'Dab' while in combat, you will instantly defeat any hater.")
exec(open("FirstHater.py").read());