print("""

_________________________
|                       |   
|   Forget the haters   |
|   live your life!     | 
|your world is your own!|
\_______________________/



""")

exec(open("Level_2_Troll1.py").read());